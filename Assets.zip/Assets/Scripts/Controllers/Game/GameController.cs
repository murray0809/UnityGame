using System;   // �� �ǉ�
using UnityEngine;

public class GameController : MonoBehaviour
{
    private GameModel model;

    [SerializeField]
    private GameView view;

    [SerializeField]
    private GameUI gameUI;

    public bool IsGameEnded { get; private set; }   // �� �ǉ�

    // �Q�[���I���i�s�k�j��ʒm����C�x���g
    public event Action OnGameOver;   // �� �ǉ�

    // �Q�[���I���i�N���A�j��ʒm����C�x���g
    public event Action OnGameClear;   // �� �ǉ�

    private void Awake()
    {
        model = new GameModel(20, 200);
    }

    private void Start()
    {
        UpdateUI();
    }

    public void DamageLife(int damage)
    {
        if (IsGameEnded) return;   // �� �ǉ�

        model.DecreaseLife(damage);

        Debug.Log("Life: " + model.Life);

        UpdateUI();

        if (model.Life <= 0)
        {
            GameOver();
        }
    }

    public bool TryBuyTower(int cost)
    {
        if (IsGameEnded) return false;   // �� �ǉ�

        bool success = model.TrySpendMoney(cost);

        if (success)
        {
            Debug.Log("Tower purchased! Money: " + model.Money);
            UpdateUI();
        }
        else
        {
            Debug.Log("Not enough money!");
        }

        return success;
    }

    public void AddMoney(int amount)
    {
        if (IsGameEnded) return;   // �� �ǉ�

        model.AddMoney(amount);

        Debug.Log("Money: " + model.Money);

        UpdateUI();
    }

    private void UpdateUI()
    {
        if (gameUI == null)
        {
            return;
        }

        gameUI.UpdateLife(model.Life);
        gameUI.UpdateMoney(model.Money);
    }

    // After
    private void GameOver()
    {
        IsGameEnded = true;
        Debug.Log("Game Over!");

        if (gameUI != null)
        {
            gameUI.ShowResult("GAME OVER");
        }

        OnGameOver?.Invoke();
    }

    public void GameClear()
    {
        if (IsGameEnded) return;

        IsGameEnded = true;
        Debug.Log("Game Clear!");

        if (gameUI != null)
        {
            gameUI.ShowResult("GAME CLEAR");
        }

        OnGameClear?.Invoke();
    }
}