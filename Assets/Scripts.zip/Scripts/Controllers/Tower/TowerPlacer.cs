using UnityEngine;
using UnityEngine.InputSystem;

public class TowerPlacer : MonoBehaviour
{
    [SerializeField]
    private GameObject towerPrefab;

    [SerializeField]
    private GameObject magicTowerPrefab;

    [SerializeField]
    private Collider2D placementArea;

    [SerializeField]
    private Collider2D enemyPath;

    [SerializeField]
    private TowerUpgradeUI towerUpgradeUI;

    private GameController gameController;

    // ���ݑI�����Ă���Tower
    private GameObject selectedTowerPrefab;

    private void Awake()
    {
        gameController =
            FindFirstObjectByType<GameController>();

        // �ŏ��͒ʏ�Tower��I��
        selectedTowerPrefab = towerPrefab;
    }

    private void Update()
    {
        if (Mouse.current == null)
        {
            Debug.Log("Mouse.current �� null");
            return;
        }

        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Debug.Log("�N���b�N���o");

            Vector2 mousePosition =
                Mouse.current.position.ReadValue();

            Vector3 screenPosition =
                new Vector3(
                    mousePosition.x,
                    mousePosition.y,
                    -Camera.main.transform.position.z
                );

            Vector3 worldPosition =
                Camera.main.ScreenToWorldPoint(screenPosition);

            worldPosition.z = 0f;

            Debug.Log("�N���b�N�ʒu: " + worldPosition);

            Collider2D[] hits =
                Physics2D.OverlapPointAll(worldPosition);

            foreach (Collider2D hit in hits)
            {
                Debug.Log("Collider����: " + hit.gameObject.name);

                TowerController tower =
                    hit.GetComponent<TowerController>();

                if (tower != null)
                {
                    Debug.Log("Tower����");

                    towerUpgradeUI.Show(tower);

                    return;
                }
            }

            PlaceTower();
        }
    }

    private void PlaceTower()
    {
        Vector2 mousePosition =
            Mouse.current.position.ReadValue();

        Vector3 screenPosition =
            new Vector3(
                mousePosition.x,
                mousePosition.y,
                -Camera.main.transform.position.z
            );

        Vector3 worldPosition =
            Camera.main.ScreenToWorldPoint(screenPosition);

        worldPosition.z = 0f;

        // �ݒu�\�G���A�O�Ȃ�I��
        if (!placementArea.OverlapPoint(worldPosition))
        {
            Debug.Log("�ݒu�\�G���A�O�ł��B");
            return;
        }

        // �G�̒ʘH��Ȃ�I��
        if (enemyPath.OverlapPoint(worldPosition))
        {
            Debug.Log("�G�̒ʘH�ɂ�Tower��u���܂���B");
            return;
        }

        int cost =
            selectedTowerPrefab == towerPrefab ? 50 : 100;

        if (!gameController.TryBuyTower(cost))
        {
            return;
        }

        Instantiate(
            selectedTowerPrefab,
            worldPosition,
            Quaternion.identity
        );

        Debug.Log(
            selectedTowerPrefab.name +
            "��ݒu���܂����B"
        );
    }

    // �ʏ�Tower��I��
    public void SelectNormalTower()
    {
        selectedTowerPrefab = towerPrefab;

        Debug.Log("�ʏ�Tower��I�����܂����B");
    }

    // MagicTower��I��
    public void SelectMagicTower()
    {
        selectedTowerPrefab = magicTowerPrefab;

        Debug.Log("MagicTower��I�����܂����B");
    }
}